const METHODS = new Set(['getMe', 'getWebhookInfo', 'getUpdates', 'sendMessage', 'sendChatAction']);
const MAX_REQUEST_BYTES = 16 * 1024;
const encoder = new TextEncoder();
const responseHeaders = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'X-Telegram-Pages-Relay': '1',
};

function error(status, code) {
  return Response.json({ok: false}, {
    status,
    headers: {...responseHeaders, 'X-Telegram-Pages-Relay-Error': code},
  });
}

async function readJson(request) {
  const reader = request.body?.getReader();
  if (!reader) throw new Error('Missing body');
  const chunks = [];
  let size = 0;
  while (true) {
    const {done, value} = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > MAX_REQUEST_BYTES) {
      await reader.cancel();
      throw new Error('Body too large');
    }
    chunks.push(value);
  }
  const body = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    body.set(chunk, offset);
    offset += chunk.byteLength;
  }
  const value = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(body));
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid body');
  return value;
}

export default {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (request.method === 'GET' && path === '/') {
      return Response.json({relay: 'telegram-pages', version: 3}, {headers: responseHeaders});
    }
    const method = path.startsWith('/telegram/') ? path.slice(10) : '';
    if (request.method !== 'POST' || !METHODS.has(method)) return error(404, 'route');

    const key = env.RELAY_KEY || '';
    const token = env.TELEGRAM_BOT_TOKEN || '';
    if (!/^[A-Za-z0-9_-]{32,128}$/.test(key) || !/^[1-9][0-9]{0,19}:[A-Za-z0-9_-]{20,100}$/.test(token)) {
      return error(424, 'config');
    }
    const authorization = encoder.encode(request.headers.get('Authorization') || '');
    const expected = encoder.encode('Bearer ' + key);
    if (authorization.byteLength !== expected.byteLength ||
        !crypto.subtle.timingSafeEqual(authorization, expected)) return error(403, 'auth');

    let body;
    try {
      body = await readJson(request);
    } catch {
      return error(400, 'body');
    }

    try {
      const upstream = await fetch('https://api.telegram.org/bot' + token + '/' + method, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(body),
        redirect: 'manual',
      });
      if ((upstream.status >= 300 && upstream.status < 400) ||
          !upstream.headers.get('Content-Type')?.toLowerCase().includes('application/json')) {
        return error(502, 'upstream');
      }
      return new Response(upstream.body, {status: upstream.status, headers: responseHeaders});
    } catch {
      return error(502, 'upstream');
    }
  },
};
